To regenerate project.lock.json after updating project.json please run dnu.cmd restore project.json --lock.

DNU can be obtained at http://github.com/aspnet/home.